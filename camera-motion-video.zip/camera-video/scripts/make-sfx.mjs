// SFX সিন্থেসাইজার — শূন্য ডাউনলোড, সম্পূর্ণ ডিটারমিনিস্টিক। আউটপুট: public/sfx/*.wav (44.1kHz, 16-bit, mono)
import fs from "node:fs";
import path from "node:path";
const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });

// ---------- helpers ----------
const rng = (seed) => () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const buf = (sec) => new Float64Array(Math.round(sec * SR));
// RBJ biquad, freq/Q may vary per sample (functions)
function biquad(x, type, freqFn, qFn = () => 0.707) {
  const y = new Float64Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let n = 0; n < x.length; n++) {
    const f = Math.min(freqFn(n / SR), SR * 0.45), q = qFn(n / SR);
    const w = (2 * Math.PI * f) / SR, cw = Math.cos(w), sw = Math.sin(w), al = sw / (2 * q);
    let b0, b1, b2, a0 = 1 + al, a1 = -2 * cw, a2 = 1 - al;
    if (type === "lp") { b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2; }
    else if (type === "hp") { b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = (1 + cw) / 2; }
    else { b0 = al; b1 = 0; b2 = -al; } // bp (constant 0 dB peak gain)
    const o = (b0 * x[n] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x[n]; y2 = y1; y1 = o; y[n] = o;
  }
  return y;
}
const lp = (x, f, q) => biquad(x, "lp", typeof f === "function" ? f : () => f, q ? () => q : undefined);
const hp = (x, f, q) => biquad(x, "hp", typeof f === "function" ? f : () => f, q ? () => q : undefined);
const bp = (x, f, q) => biquad(x, "bp", typeof f === "function" ? f : () => f, typeof q === "function" ? q : () => q);
// খুব ছোট reverb (Schroeder: 4 comb + 2 allpass), wet কম
function tinyReverb(x, wet = 0.1, decay = 0.35) {
  const delays = [1031, 1327, 1559, 1801].map((d) => Math.round(d * 0.8));
  const out = new Float64Array(x.length);
  for (const d of delays) {
    const fb = Math.pow(0.001, d / (decay * SR));
    const c = new Float64Array(x.length);
    for (let n = 0; n < x.length; n++) c[n] = x[n] + (n >= d ? c[n - d] * fb : 0);
    for (let n = 0; n < x.length; n++) out[n] += c[n] / delays.length;
  }
  let ap = out;
  for (const [d, g] of [[225, 0.5], [341, 0.5]]) {
    const y = new Float64Array(ap.length);
    for (let n = 0; n < ap.length; n++) {
      const dl = n >= d ? y[n - d] : 0, xd = n >= d ? ap[n - d] : 0;
      y[n] = -g * ap[n] + xd + g * dl;
    }
    ap = y;
  }
  return x.map((v, n) => v + wet * ap[n]);
}
const edgeFade = (x, inMs = 2, outMs = 25) => {
  const a = Math.round((inMs / 1000) * SR), b = Math.round((outMs / 1000) * SR);
  for (let n = 0; n < a && n < x.length; n++) x[n] *= 0.5 - 0.5 * Math.cos((Math.PI * n) / a);
  for (let n = 0; n < b && n < x.length; n++) x[x.length - 1 - n] *= 0.5 - 0.5 * Math.cos((Math.PI * n) / b);
  return x;
};
const peakOf = (x) => x.reduce((m, v) => Math.max(m, Math.abs(v)), 0);
// gated RMS: শুধু যেখানে সাউন্ড সক্রিয়
const gatedRms = (x) => {
  const pk = peakOf(x), th = pk * 0.05;
  let s = 0, c = 0;
  for (const v of x) if (Math.abs(v) > th) { s += v * v; c++; }
  return Math.sqrt(s / Math.max(c, 1));
};
function writeWav(name, x) {
  const data = Buffer.alloc(x.length * 2);
  let clip = 0;
  for (let n = 0; n < x.length; n++) {
    let v = Math.round(x[n] * 32767);
    if (v > 32767 || v < -32768) { clip++; v = Math.max(-32768, Math.min(32767, v)); }
    data.writeInt16LE(v, n * 2);
  }
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8); h.write("fmt ", 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write("data", 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(OUT, name), Buffer.concat([h, data]));
  return clip;
}
const sineSweep = (x, fFn, ampFn) => {
  let ph = 0;
  for (let n = 0; n < x.length; n++) { const t = n / SR; ph += (2 * Math.PI * fFn(t)) / SR; x[n] += Math.sin(ph) * ampFn(t); }
  return x;
};
const smooth = (t, a, d) => (t < a ? 0.5 - 0.5 * Math.cos((Math.PI * t) / a) : Math.exp(-(t - a) / d));

// ---------- sounds ----------
const sounds = {};

// 1) pop — দ্রুত নিচে নামা pitch সহ sine + ছোট envelope (নরম)
sounds.pop = () => {
  const x = buf(0.28);
  sineSweep(x, (t) => 180 + 360 * Math.exp(-t / 0.028), (t) => smooth(t, 0.004, 0.055));
  const h = buf(0.28);
  sineSweep(h, (t) => 2 * (180 + 360 * Math.exp(-t / 0.028)), (t) => 0.18 * smooth(t, 0.003, 0.035));
  for (let n = 0; n < x.length; n++) x[n] += h[n];
  return tinyReverb(lp(x, 4200), 0.07, 0.2);
};

// 2) click — high-pass করা ছোট noise burst + অতি ছোট টোনাল টিক
sounds.click = () => {
  const r = rng(7), x = buf(0.14);
  for (let n = 0; n < x.length; n++) { const t = n / SR; x[n] = (r() * 2 - 1) * smooth(t, 0.0006, 0.011); }
  const noise = hp(x, 2400, 0.8);
  const tick = buf(0.14);
  sineSweep(tick, () => 1750, (t) => 0.35 * smooth(t, 0.0005, 0.007));
  for (let n = 0; n < noise.length; n++) noise[n] += tick[n];
  return lp(noise, 9000);
};

// 3) whoosh — band-pass noise sweep, fade in/out (নরম, ওপরে ওঠা)
sounds.whoosh = () => {
  const L = 0.58, r = rng(21), x = buf(L);
  for (let n = 0; n < x.length; n++) x[n] = r() * 2 - 1;
  const f = (t) => 380 * Math.pow(2600 / 380, Math.min(t / L, 1));
  const y = bp(x, f, () => 1.1);
  for (let n = 0; n < y.length; n++) { const t = n / SR / L; y[n] *= Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 2); }
  return tinyReverb(lp(y, 6500), 0.06, 0.25);
};

// 4) swipe — ট্রানজিশনের জন্য মসৃণ, নিচে নামা sweep (whoosh থেকে আলাদা)
sounds.swipe = () => {
  const L = 0.7, r = rng(33), x = buf(L);
  for (let n = 0; n < x.length; n++) x[n] = r() * 2 - 1;
  const f = (t) => 2600 * Math.pow(420 / 2600, Math.min(t / L, 1));
  const y = bp(x, f, () => 0.9);
  for (let n = 0; n < y.length; n++) { const t = n / SR / L; y[n] *= Math.pow(Math.sin(Math.PI * Math.pow(t, 0.65)), 2.2); }
  return tinyReverb(lp(y, 5800), 0.06, 0.25);
};

// 5) chime — নরম ওভারটোনসহ ছোট decay (pluck/chime)
sounds.chime = () => {
  const x = buf(0.5), base = 880;
  const partials = [[1, 1, 0.16], [2.003, 0.32, 0.1], [3.01, 0.16, 0.06], [4.2, 0.07, 0.035]];
  for (const [m, a, tau] of partials) {
    const p = buf(0.5);
    sineSweep(p, () => base * m, (t) => a * smooth(t, 0.004, tau));
    for (let n = 0; n < x.length; n++) x[n] += p[n];
  }
  return tinyReverb(lp(x, 6200), 0.1, 0.3);
};

// 6) thud — খুব হালকা সফট থাড (হুক/মূল বার্তা, সংযত)
sounds.thud = () => {
  const x = buf(0.36);
  sineSweep(x, (t) => 48 + 80 * Math.exp(-t / 0.035), (t) => smooth(t, 0.006, 0.09));
  const r = rng(5), n2 = buf(0.36);
  for (let n = 0; n < n2.length; n++) n2[n] = (r() * 2 - 1) * smooth(n / SR, 0.002, 0.012) * 0.18;
  const nz = lp(n2, 900);
  for (let n = 0; n < x.length; n++) x[n] += nz[n];
  return lp(x, 700);
};

// ---------- render + level match ----------
const TARGET_RMS = Math.pow(10, -19 / 20); // ≈ -19 dBFS (সক্রিয় অংশে)
const PEAK_CEIL = 0.85;
const report = [];
for (const [name, make] of Object.entries(sounds)) {
  let x = edgeFade(make());
  const g = TARGET_RMS / gatedRms(x);
  x = x.map((v) => v * g);
  if (peakOf(x) > PEAK_CEIL) { const k = PEAK_CEIL / peakOf(x); x = x.map((v) => v * k); }
  const clip = writeWav(`${name}.wav`, x);
  report.push({ name, sec: +(x.length / SR).toFixed(3), peak: +peakOf(x).toFixed(3), clip });
}
console.table(report);
