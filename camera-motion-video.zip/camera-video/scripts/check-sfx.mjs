// SFX যাচাই: দৈর্ঘ্য, peak (dBFS), clipping, gated RMS
import fs from "node:fs";
const dir = new URL("../public/sfx/", import.meta.url).pathname;
let bad = 0;
for (const f of fs.readdirSync(dir).filter((f) => f.endsWith(".wav")).sort()) {
  const b = fs.readFileSync(dir + f), n = (b.length - 44) / 2;
  let pk = 0, clip = 0; const xs = new Float64Array(n);
  for (let i = 0; i < n; i++) { const v = b.readInt16LE(44 + i * 2); xs[i] = v / 32768; pk = Math.max(pk, Math.abs(xs[i])); if (Math.abs(v) >= 32767) clip++; }
  const th = pk * 0.05; let s = 0, c = 0; for (const v of xs) if (Math.abs(v) > th) { s += v * v; c++; }
  const rms = Math.sqrt(s / Math.max(c, 1)), sec = n / 44100;
  const lim = f.startsWith("whoosh") || f.startsWith("swipe") ? 0.8 : 0.5;
  const ok = sec <= lim && clip === 0 && pk < 0.95;
  if (!ok) bad++;
  console.log(f.padEnd(12), "dur", sec.toFixed(3) + "s", "peak", (20 * Math.log10(pk)).toFixed(1) + "dBFS", "rms", (20 * Math.log10(rms)).toFixed(1) + "dBFS", "clip", clip, ok ? "OK" : "FAIL");
}
process.exit(bad ? 1 : 0);
