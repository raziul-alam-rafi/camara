// প্রজেক্ট-লেভেল কনফিগ
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

/** ভিজ্যুয়াল সংশ্লিষ্ট কথার কতটা ফ্রেম আগে ঢুকবে (৪–৬) */
export const LEAD = 5;
/** সিনের মধ্যে ওভারল্যাপ (ট্রানজিশন) ফ্রেম */
export const OVERLAP = 8;

/** public/voiceover.mp3 থাকলে Studio প্রিভিউতে বাজবে */
export const VOICEOVER_IN_PREVIEW = true;
/** ডিফল্টে রেন্ডারে ভয়েসওভার বন্ধ; চাইলে true করুন */
export const VOICEOVER_IN_RENDER = false;
