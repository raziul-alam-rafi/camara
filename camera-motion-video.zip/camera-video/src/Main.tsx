import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame } from "remotion";
import { theme } from "./theme";
import { SCENES } from "./timeline";
import { SceneCtx, SceneShell } from "./lib/scene";
import { BgMesh, Grade, Grain, Vignette } from "./components/Backdrop";
import { PreviewAudio, SfxLayer } from "./components/Audio";
import { CL } from "./lib/anim";
import { SceneHook } from "./scenes/SceneHook";
import { SceneFlow } from "./scenes/SceneFlow";
import { SceneSplit } from "./scenes/SceneSplit";
import { SceneDetect } from "./scenes/SceneDetect";
import { SceneDive } from "./scenes/SceneDive";
import { SceneRecap } from "./scenes/SceneRecap";
import { SceneCta } from "./scenes/SceneCta";

const COMPONENTS: Record<string, React.FC> = {
  hook: SceneHook,
  flow: SceneFlow,
  split: SceneSplit,
  detect: SceneDetect,
  dive: SceneDive,
  recap: SceneRecap,
  cta: SceneCta,
};

/** সিন কাটে একটি আলোর সুইপ (মাস্ক-ওয়াইপ) */
const Sweeps: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      {SCENES.slice(1).map((s) => {
        const p = interpolate(frame, [s.from - 3, s.from + 13], [0, 1], { easing: theme.ease.inOut, ...CL });
        if (p <= 0 || p >= 1) return null;
        const x = -520 + p * 2960;
        return (
          <div
            key={s.id}
            style={{
              position: "absolute",
              top: -100,
              bottom: -100,
              left: x,
              width: 460,
              transform: "skewX(-14deg)",
              background: `linear-gradient(90deg, transparent, ${theme.colors.primary}55, ${theme.colors.text}33, transparent)`,
              opacity: Math.sin(Math.PI * p) * 0.8,
              mixBlendMode: "screen",
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg }}>
    {/* ১. ব্যাকগ্রাউন্ড মেশ */}
    <BgMesh />
    {/* ২–৩. অ্যাসেট/গ্রাফিক্স/টাইপ (সিন) */}
    {SCENES.map((s) => {
      const Comp = COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={s.id}>
          <SceneCtx.Provider value={{ from: s.from, duration: s.duration, index: s.index, last: s.index === SCENES.length - 1 }}>
            <SceneShell>
              <Comp />
            </SceneShell>
          </SceneCtx.Provider>
        </Sequence>
      );
    })}
    <Sweeps />
    {/* ৪. কালার গ্রেড ৫. গ্রেইন + ভিনিয়েট */}
    <Grade />
    <Grain />
    <Vignette />
    {/* অডিও */}
    <SfxLayer />
    <PreviewAudio />
  </AbsoluteFill>
);
