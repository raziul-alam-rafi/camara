// timeline.ts — সব সময়ের হিসাব SRT (src/data/cues.ts) থেকে। হাতে কোনো ফ্রেম বসানো নেই।
import { CUES, Cue } from "./data/cues";
import { FPS, LEAD, OVERLAP } from "./config";

export const sec2f = (s: number) => Math.round(s * FPS);
export const cue = (n: number): Cue => {
  const c = CUES.find((q) => q.index === n);
  if (!c) throw new Error(`cue ${n} নেই`);
  return c;
};

/**
 * cue-র ভেতরে কোনো শব্দ/বাক্যাংশ কখন উচ্চারিত হবে — cue-র সময়ের মধ্যে
 * অক্ষর-অনুপাতে আনুমানিক হিসাব (SRT-এ শব্দ-স্তরের সময় নেই)।
 */
export const phrase = (n: number, needle: string, nth = 0): number => {
  const c = cue(n);
  let idx = -1;
  for (let k = 0; k <= nth; k++) {
    idx = c.text.indexOf(needle, idx + 1);
    if (idx < 0) throw new Error(`cue ${n}-এ "${needle}" নেই`);
  }
  return c.start + (idx / c.text.length) * (c.end - c.start);
};

// ---------- সিন বিভাজন (সীমা cue-র সীমায়) ----------
type SceneDef = { id: string; first: number; last: number };
const DEFS: SceneDef[] = [
  { id: "hook", first: 1, last: 1 },
  { id: "flow", first: 2, last: 3 },
  { id: "split", first: 4, last: 5 },
  { id: "detect", first: 6, last: 6 },
  { id: "dive", first: 7, last: 7 },
  { id: "recap", first: 8, last: 8 },
  { id: "cta", first: 9, last: 9 },
];

export const TOTAL = Math.ceil(cue(CUES.length).end * FPS);

export type SceneInfo = SceneDef & {
  index: number;
  startSec: number;
  endSec: number;
  from: number;
  duration: number;
};

const bases = DEFS.map((d, i) => (i === 0 ? 0 : sec2f(cue(d.first).start) - LEAD));
export const SCENES: SceneInfo[] = DEFS.map((d, i) => {
  const from = bases[i];
  const end = i === DEFS.length - 1 ? TOTAL : bases[i + 1] + OVERLAP;
  return {
    ...d,
    index: i,
    startSec: cue(d.first).start,
    endSec: cue(d.last).end,
    from,
    duration: end - from,
  };
});

// ---------- ইভেন্ট (সেকেন্ডে; সিন ও SFX একই টেবিল থেকে পড়ে) ----------
export const EV = {
  hook: {
    label: phrase(1, "আপনি"),
    shutter: phrase(1, "তোলেন"),
    title: phrase(1, "ক্যামেরার"),
    emph: phrase(1, "কী ঘটে"),
    ask: phrase(1, "জানেন"),
  },
  flow: {
    badge: cue(2).start,
    c1: phrase(2, "আলো ধরে"),
    c2: phrase(2, "বিদ্যুতে"),
    c3: cue(3).start,
    c4: phrase(3, "পরিচিত"),
    wow: phrase(3, "অবাক"),
  },
  split: {
    head1: phrase(4, "ক্যামেরার"),
    p1: phrase(4, "মানুষটা"),
    p2: phrase(4, "গাছটা"),
    p3: phrase(4, "পৃথিবীর"),
    head2: phrase(4, "কোনো"),
    none: phrase(5, "ছবিই"),
    light: phrase(5, "আলো"),
    signal: phrase(5, "ইলেকট্রনিক"),
    so: phrase(5, "তাহলে"),
  },
  detect: {
    lead: phrase(6, "থেকেই"),
    how: phrase(6, "কীভাবে"),
    face: phrase(6, "মুখ"),
    sky: phrase(6, "আকাশ"),
    tree: phrase(6, "গাছ"),
  },
  dive: {
    today: phrase(7, "আজ"),
    inside: phrase(7, "ক্যামেরার"),
    enter: phrase(7, "ঢুকে"),
    journey: phrase(7, "একেবারে"),
    start: phrase(7, "শুরু"),
    end: phrase(7, "শেষ"),
    mystery: phrase(7, "রহস্যটাই"),
    solve: phrase(7, "বুঝব"),
  },
  recap: {
    first: phrase(8, "পুরো"),
    word: phrase(8, "মেকানিজম"),
    clear: phrase(8, "পানির"),
  },
  cta: {
    clear: phrase(9, "মতো"),
    go: phrase(9, "চলুন"),
    start: phrase(9, "শুরু"),
  },
} as const;

/** recap-এ ৪টি আইটেম cue-র সময়ে সমান ব্যবধানে (প্রতিটি আইটেম আলাদা করে উচ্চারিত নয়) */
export const RECAP_ITEMS = 4;
export const recapSec = (i: number) =>
  EV.recap.first + ((EV.recap.clear - EV.recap.first) * i) / RECAP_ITEMS;

// ---------- SFX তালিকা ----------
export type SfxName = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";
export type SfxEvent = { frame: number; name: SfxName; volume: number; rate: number };
export const SFX_LEN: Record<SfxName, number> = { pop: 0.28, click: 0.14, whoosh: 0.58, swipe: 0.7, chime: 0.5, thud: 0.36 };

/** ভিজ্যুয়াল ঢোকার ২ ফ্রেম আগে সাউন্ড */
const g = (sec: number) => Math.max(0, sec2f(sec) - LEAD - 2);
const S = (sec: number, name: SfxName, volume: number, rate = 1): SfxEvent => ({ frame: g(sec), name, volume, rate });

export const SFX: SfxEvent[] = [
  // হুক
  { frame: 0, name: "pop", volume: 0.26, rate: 1 },
  S(EV.hook.shutter, "click", 0.3, 1),
  S(EV.hook.title, "whoosh", 0.28, 1),
  S(EV.hook.emph, "thud", 0.24, 1),
  // ফ্লো
  S(EV.flow.c1, "pop", 0.28, 1),
  S(EV.flow.c2, "pop", 0.26, 1.06),
  S(EV.flow.c3, "pop", 0.3, 0.96),
  S(EV.flow.c4, "pop", 0.27, 1.03),
  // স্প্লিট
  S(EV.split.p1, "pop", 0.24, 1),
  S(EV.split.p2, "pop", 0.22, 1.05),
  S(EV.split.p3, "pop", 0.25, 0.95),
  S(EV.split.none, "click", 0.32, 0.94),
  S(EV.split.light, "pop", 0.26, 1.04),
  S(EV.split.signal, "pop", 0.26, 0.97),
  // ডিটেক্ট
  S(EV.detect.how, "whoosh", 0.28, 1.04),
  S(EV.detect.face, "click", 0.3, 1),
  S(EV.detect.sky, "click", 0.28, 1.07),
  S(EV.detect.tree, "click", 0.3, 0.95),
  // ডাইভ
  S(EV.dive.inside, "whoosh", 0.3, 0.96),
  S(EV.dive.mystery, "thud", 0.26, 1),
  // রিক্যাপ
  ...Array.from({ length: RECAP_ITEMS }, (_, i) =>
    S(recapSec(i), "click", 0.28 + (i % 2) * 0.03, [1, 1.06, 0.96, 1.03][i]),
  ),
  // CTA
  S(EV.cta.go, "whoosh", 0.26, 1.05),
  S(EV.cta.start, "chime", 0.3, 1),
  // সিন ট্রানজিশন
  ...SCENES.slice(1).map((s, i) => ({
    frame: Math.max(0, s.from - 2),
    name: "swipe" as SfxName,
    volume: 0.26 + (i % 2) * 0.04,
    rate: [1, 0.97, 1.04, 0.99, 1.02, 0.98][i],
  })),
].sort((a, b) => a.frame - b.frame);
