// সিন ২ — Timeline Process Flow (Glossy কার্ড) | cue 2–3
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV } from "../timeline";
import { useAt } from "../lib/scene";
import { CL, floatY, ramp } from "../lib/anim";
import { Entrance, WordReveal } from "../components/Motion";
import { GlassCard } from "../components/GlassCard";
import { IconBolt, IconClock, IconLight, IconPhoto } from "../components/Icons";

const CARD_W = 340;
const CARD_H = 400;
const CARD_TOP = 340;
const X0 = 100;
const STEP = 460;
const cx = (i: number) => X0 + i * STEP;
const CY = CARD_TOP + CARD_H / 2;

const FlowIcon: React.FC<{ i: number }> = ({ i }) => {
  const frame = useCurrentFrame();
  const size = 96;
  if (i === 0)
    return (
      <div style={{ transform: `rotate(${frame * 0.7}deg) scale(${1 + Math.sin(frame / 14) * 0.05})` }}>
        <IconLight size={size} color={theme.colors.accent} />
      </div>
    );
  if (i === 1)
    return (
      <div style={{ transform: `scale(${1 + Math.sin(frame / 9) * 0.06})`, opacity: 0.82 + 0.18 * Math.sin(frame / 5) }}>
        <IconBolt size={size} color={theme.colors.text} fill={`${theme.colors.text}22`} />
      </div>
    );
  if (i === 2)
    return (
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 26px)", gap: 8 }}>
        {Array.from({ length: 9 }).map((_, k) => (
          <div
            key={k}
            style={{
              width: 26,
              height: 26,
              borderRadius: 7,
              border: `2px solid ${theme.colors.text}`,
              background: theme.colors.text,
              opacity: 0.18 + 0.82 * Math.max(0, Math.sin(frame / 7 + k * 1.3)) ** 2,
            }}
          />
        ))}
      </div>
    );
  const sweep = ((frame * 0.014) % 1.6) - 0.3;
  return (
    <div style={{ position: "relative", width: size, height: size, overflow: "hidden", borderRadius: 24 }}>
      <IconPhoto size={size} color={theme.colors.text} />
      <div
        style={{
          position: "absolute",
          top: -10,
          bottom: -10,
          width: 34,
          left: `${sweep * 100}%`,
          transform: "skewX(-20deg)",
          background: `linear-gradient(90deg, transparent, ${theme.colors.white}55, transparent)`,
        }}
      />
    </div>
  );
};

const LABELS = ["আলো ধরে", "বিদ্যুতে রূপান্তর", "কোটি কোটি হিসাব", "আপনার পরিচিত ছবি"];

export const SceneFlow: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useAt();
  const T = [at(EV.flow.c1), at(EV.flow.c2), at(EV.flow.c3), at(EV.flow.c4)];
  const tBadge = Math.max(0, at(EV.flow.badge));

  // টাইমলাইন ট্র্যাক
  const trackFill = interpolate(frame, [T[0], T[1], T[2], T[3]], [cx(0) + CARD_W / 2, cx(1) + CARD_W / 2, cx(2) + CARD_W / 2, cx(3) + CARD_W / 2], {
    easing: theme.ease.out,
    ...CL,
  });
  const trackY = 900;

  return (
    <AbsoluteFill>
      {/* শিরোনাম */}
      <div style={{ position: "absolute", top: 96, left: 0, right: 0, display: "flex", justifyContent: "center", alignItems: "center", gap: 28 }}>
        <Entrance delay={tBadge} y={20} from={0.7} config={theme.spring.bouncy}>
          <IconClock size={96} color={theme.colors.accent} />
        </Entrance>
        <WordReveal text="এক সেকেন্ডেরও কম সময়ে" delay={tBadge + 3} per={4} size={96} kinds={{ 2: "hero" }} />
      </div>

      {/* কানেক্টর */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {[0, 1, 2].map((i) => {
          const x1 = cx(i) + CARD_W + 14;
          const x2 = cx(i + 1) - 14;
          const p = ramp(frame, T[i + 1] - 10, 16);
          const pulse = ((frame * 0.018 + i * 0.33) % 1) * p;
          return (
            <g key={i}>
              <line x1={x1} y1={CY} x2={x1 + (x2 - x1) * p} y2={CY} stroke={theme.colors.textDim} strokeWidth={4} strokeLinecap="round" strokeDasharray="2 12" />
              <polyline
                points={`${x2 - 16},${CY - 14} ${x2},${CY} ${x2 - 16},${CY + 14}`}
                fill="none"
                stroke={theme.colors.textDim}
                strokeWidth={4}
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity={p > 0.92 ? 1 : 0}
              />
              <circle cx={x1 + (x2 - x1) * pulse} cy={CY} r={9} fill={theme.colors.accent} opacity={Math.sin(Math.PI * pulse) * 0.95} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.accentGlow})` }} />
            </g>
          );
        })}
        {/* ট্র্যাক */}
        <line x1={cx(0) + CARD_W / 2} y1={trackY} x2={cx(3) + CARD_W / 2} y2={trackY} stroke={theme.colors.line} strokeWidth={6} strokeLinecap="round" />
        <line x1={cx(0) + CARD_W / 2} y1={trackY} x2={trackFill} y2={trackY} stroke={theme.colors.primary} strokeWidth={6} strokeLinecap="round" style={{ filter: `drop-shadow(0 0 10px ${theme.colors.glow})` }} />
        {[0, 1, 2, 3].map((i) => {
          const p = spring({ frame: frame - T[i], fps, config: theme.spring.bouncy });
          const lit = frame >= T[i];
          return (
            <circle key={i} cx={cx(i) + CARD_W / 2} cy={trackY} r={13 * Math.min(1.25, Math.max(0.8, 0.8 + 0.2 * p)) + (lit ? 3 : 0)} fill={lit ? theme.colors.primary : theme.colors.bg} stroke={lit ? theme.colors.text : theme.colors.line} strokeWidth={3} />
          );
        })}
      </svg>

      {/* ঘোস্ট স্লট: ধারাটা আগেই বোঝা যায়, কনটেন্ট কথার সময়ে ভরে */}
      {LABELS.map((_, i) => (
        <div key={`g${i}`} style={{ position: "absolute", left: cx(i), top: CARD_TOP, opacity: 1 - ramp(frame, T[i], 6) }}>
          <Entrance delay={4 + i * 5} y={30} from={0.96}>
            <div style={{ width: CARD_W, height: CARD_H, borderRadius: theme.radius.md, border: `2.5px dashed ${theme.colors.line}`, opacity: 0.7 }} />
          </Entrance>
        </div>
      ))}

      {/* কার্ড */}
      {LABELS.map((label, i) => {
        const active = ramp(frame, T[i], 8) * (i < 3 ? 1 - ramp(frame, T[i + 1], 10) : 1);
        return (
          <div key={i} style={{ position: "absolute", left: cx(i), top: CARD_TOP, transform: `translateY(${floatY(frame, 4, 32, i * 1.2)}px)` }}>
            <Entrance delay={T[i]} y={70} from={0.88} config={theme.spring.snappy}>
              <GlassCard width={CARD_W} height={CARD_H} active={active}>
                <div style={{ position: "absolute", left: 28, top: 18, fontFamily: theme.fonts.display, fontSize: 32, fontWeight: theme.weight.strong, color: theme.colors.textDim, letterSpacing: 0 }}>
                  0{i + 1}
                </div>
                <div style={{ position: "absolute", left: 0, right: 0, top: 64, display: "flex", justifyContent: "center" }}>
                  <div
                    style={{
                      width: 170,
                      height: 170,
                      borderRadius: 48,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      background: `radial-gradient(circle at 50% 35%, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
                      border: `1.5px solid ${theme.colors.lineSoft}`,
                    }}
                  >
                    <FlowIcon i={i} />
                  </div>
                </div>
                <div
                  style={{
                    position: "absolute",
                    left: 22,
                    right: 22,
                    bottom: 30,
                    height: 140,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    textAlign: "center",
                    fontFamily: theme.fonts.display,
                    fontWeight: theme.weight.hero,
                    fontSize: 52,
                    lineHeight: 1.3,
                    letterSpacing: 0,
                    color: theme.colors.text,
                  }}
                >
                  {label}
                </div>
              </GlassCard>
            </Entrance>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
