// সিন ৪ — Glossy UI Mockup (ভিউফাইন্ডার + শনাক্তকরণ বক্স) | cue 6
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV } from "../timeline";
import { useAt } from "../lib/scene";
import { CL, floatY, ramp } from "../lib/anim";
import { Entrance, Pill, WordReveal } from "../components/Motion";

const VF = { x: 880, y: 140, w: 930, h: 800 };
const SW = 882; // দৃশ্যের সাইজ
const SH = 688;

type Box = { x: number; y: number; w: number; h: number; label: string; lx: number; ly: number };
const BOXES: Box[] = [
  { x: 232, y: 292, w: 136, h: 136, label: "মানুষের মুখ", lx: 150, ly: 222 },
  { x: 14, y: 14, w: 854, h: 196, label: "আকাশ", lx: 34, ly: 34 },
  { x: 540, y: 226, w: 200, h: 312, label: "গাছ", lx: 540, ly: 552 },
];

const Corners: React.FC<{ b: Box; color: string; sw: number }> = ({ b, color, sw }) => {
  const L = 30;
  const { x, y, w, h } = b;
  return (
    <g fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
      <polyline points={`${x},${y + L} ${x},${y} ${x + L},${y}`} />
      <polyline points={`${x + w - L},${y} ${x + w},${y} ${x + w},${y + L}`} />
      <polyline points={`${x + w},${y + h - L} ${x + w},${y + h} ${x + w - L},${y + h}`} />
      <polyline points={`${x + L},${y + h} ${x},${y + h} ${x},${y + h - L}`} />
    </g>
  );
};

export const SceneDetect: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useAt();
  const e = EV.detect;
  const tLead = Math.max(0, at(e.lead));
  const tHow = at(e.how);
  const T = [at(e.face), at(e.sky), at(e.tree)];

  // স্ক্যান
  const scanEnd = Math.max(60, T[0] - 14);
  const scan = interpolate(frame, [tLead + 12, scanEnd], [0, SH], { easing: theme.ease.inOut, ...CL });
  const flick = (n: number) => 0.35 + 0.65 * Math.abs(Math.sin(frame / 5 + n));

  return (
    <AbsoluteFill>
      {/* বাম কলাম */}
      <div style={{ position: "absolute", left: 110, top: 276, width: 740 }}>
        <Entrance delay={tLead} y={28}>
          <Pill size={42}>সিগন্যাল থেকেই</Pill>
        </Entrance>
        <div style={{ marginTop: 28 }}>
          <WordReveal text="কীভাবে" delay={tHow} per={5} size={156} kinds={{ 0: "hero" }} />
          <WordReveal text="বুঝতে পারে?" delay={tHow + 8} per={5} size={132} />
        </div>
      </div>

      {/* ভিউফাইন্ডার */}
      <div style={{ position: "absolute", left: VF.x, top: VF.y + floatY(frame, 4, 34) }}>
        <Entrance delay={tLead + 2} y={60} from={0.93} config={theme.spring.smooth}>
          <div
            style={{
              position: "relative",
              width: VF.w,
              height: VF.h,
              borderRadius: theme.radius.lg,
              background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
              border: `1.5px solid ${theme.colors.line}`,
              boxShadow: theme.shadow.card,
            }}
          >
            <div style={{ position: "absolute", inset: 0, borderRadius: theme.radius.lg, background: "linear-gradient(180deg, rgba(255,255,255,0.10), transparent 30%)" }} />
            {/* ক্রোম বার */}
            <div style={{ position: "absolute", left: 32, top: 24, display: "flex", gap: 12 }}>
              {[0, 1, 2].map((i) => (
                <div key={i} style={{ width: 16, height: 16, borderRadius: "50%", background: theme.colors.line }} />
              ))}
            </div>
            <div style={{ position: "absolute", right: 36, top: 22, display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 14, height: 14, borderRadius: "50%", background: theme.colors.accent, opacity: 0.55 + 0.45 * Math.sin(frame / 8), boxShadow: `0 0 14px ${theme.colors.accentGlow}` }} />
            </div>

            {/* দৃশ্য */}
            <div style={{ position: "absolute", left: 24, top: 64, width: SW, height: SH, borderRadius: 26, overflow: "hidden", background: theme.colors.bg }}>
              {/* সিগন্যাল গ্রিড */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  backgroundImage: `radial-gradient(circle, ${theme.colors.primary} 3px, transparent 3.6px)`,
                  backgroundSize: "26px 26px",
                  opacity: 0.28 * flick(1),
                }}
              />
              {/* রিভিল হওয়া দৃশ্য */}
              <svg width={SW} height={SH} viewBox={`0 0 ${SW} ${SH}`} style={{ position: "absolute", inset: 0 }}>
                <defs>
                  <clipPath id="reveal">
                    <rect x={0} y={0} width={SW} height={scan} />
                  </clipPath>
                  <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor={theme.colors.bgAlt} />
                    <stop offset="1" stopColor={theme.colors.primary} stopOpacity="0.55" />
                  </linearGradient>
                  <linearGradient id="ground" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0" stopColor={theme.colors.bgAlt} />
                    <stop offset="1" stopColor={theme.colors.bg} />
                  </linearGradient>
                  <radialGradient id="sun" cx="50%" cy="50%" r="50%">
                    <stop offset="0" stopColor={theme.colors.accent} stopOpacity="0.9" />
                    <stop offset="1" stopColor={theme.colors.accent} stopOpacity="0" />
                  </radialGradient>
                  <linearGradient id="skin" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stopColor={theme.colors.text} stopOpacity="0.9" />
                    <stop offset="1" stopColor={theme.colors.textDim} stopOpacity="0.8" />
                  </linearGradient>
                </defs>
                <g clipPath="url(#reveal)">
                  <rect width={SW} height={SH} fill="url(#sky)" />
                  <circle cx={140} cy={250} r={120} fill="url(#sun)" />
                  <circle cx={140} cy={250} r={34} fill={theme.colors.accent} />
                  <path d={`M0 430 C 200 380 380 470 560 420 C 700 380 800 430 ${SW} 400 V ${SH} H 0 Z`} fill="url(#ground)" />
                  {/* গাছ */}
                  <rect x={628} y={400} width={26} height={140} rx={8} fill={theme.colors.textDim} opacity={0.4} />
                  <circle cx={640} cy={318} r={78} fill={theme.colors.primary} opacity={0.5} />
                  <circle cx={586} cy={376} r={58} fill={theme.colors.primary} opacity={0.42} />
                  <circle cx={696} cy={376} r={58} fill={theme.colors.primary} opacity={0.42} />
                  {/* মানুষ */}
                  <path d="M170 600 C170 486 235 450 300 450 C365 450 430 486 430 600 Z" fill={theme.colors.textDim} opacity={0.6} />
                  <rect x={280} y={402} width={40} height={60} rx={14} fill="url(#skin)" opacity={0.85} />
                  <circle cx={300} cy={360} r={58} fill="url(#skin)" />
                </g>
                {/* স্ক্যান লাইন */}
                <g opacity={frame < scanEnd + 4 ? 1 : 0}>
                  <rect x={0} y={scan - 90} width={SW} height={90} fill={theme.colors.primary} opacity={0.16} />
                  <rect x={0} y={scan - 3} width={SW} height={6} fill={theme.colors.primary} style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glow})` }} />
                </g>
                {/* বক্স */}
                {BOXES.map((b, i) => {
                  const p = spring({ frame: frame - T[i], fps, config: theme.spring.snappy });
                  const active = ramp(frame, T[i], 6) * (i < 2 ? 1 - ramp(frame, T[i + 1], 8) : 1);
                  const sc = interpolate(p, [0, 1], [1.14, 1]);
                  const cxm = b.x + b.w / 2;
                  const cym = b.y + b.h / 2;
                  const vis = Math.min(1, Math.max(0, p * 1.5));
                  return (
                    <g key={i} opacity={vis} transform={`translate(${cxm} ${cym}) scale(${sc}) translate(${-cxm} ${-cym})`}>
                      <rect x={b.x} y={b.y} width={b.w} height={b.h} rx={10} fill={theme.colors.primary} opacity={0.12 * active + 0.04 * (1 - active)} />
                      <g opacity={1 - active}>
                        <Corners b={b} color={theme.colors.textDim} sw={4} />
                      </g>
                      <g opacity={active} style={{ filter: `drop-shadow(0 0 12px ${theme.colors.glow})` }}>
                        <Corners b={b} color={theme.colors.primary} sw={6} />
                      </g>
                    </g>
                  );
                })}
              </svg>
              {/* লেবেল চিপ */}
              {BOXES.map((b, i) => {
                const p = spring({ frame: frame - (T[i] + 3), fps, config: theme.spring.bouncy });
                const active = ramp(frame, T[i], 6) * (i < 2 ? 1 - ramp(frame, T[i + 1], 8) : 1);
                return (
                  <div
                    key={i}
                    style={{
                      position: "absolute",
                      left: b.lx,
                      top: b.ly,
                      opacity: Math.min(1, Math.max(0, p * 1.5)),
                      transform: `translateY(${interpolate(p, [0, 1], [14, 0])}px) scale(${interpolate(p, [0, 1], [0.8, 1])})`,
                      transformOrigin: "0% 100%",
                    }}
                  >
                    <div
                      style={{
                        padding: "6px 24px",
                        borderRadius: 999,
                        fontFamily: theme.fonts.display,
                        fontWeight: theme.weight.hero,
                        fontSize: 40,
                        lineHeight: 1.3,
                        letterSpacing: 0,
                        color: active > 0.5 ? theme.colors.white : theme.colors.text,
                        background: active > 0.5 ? theme.colors.primary : theme.colors.shade,
                        border: `1.5px solid ${active > 0.5 ? theme.colors.primary : theme.colors.line}`,
                        boxShadow: active > 0.5 ? `0 0 30px ${theme.colors.glow}` : undefined,
                      }}
                    >
                      {b.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Entrance>
      </div>
    </AbsoluteFill>
  );
};
