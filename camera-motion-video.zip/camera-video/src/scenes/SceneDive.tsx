// সিন ৫ — Kinetic Typography + লেন্স-টানেল ও লাইন-ড্র | cue 7
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV } from "../timeline";
import { useAt } from "../lib/scene";
import { CL, ramp } from "../lib/anim";
import { Entrance, WordReveal } from "../components/Motion";

const PATH_Y = 566;
const PX0 = 330;
const PX1 = 1590;
const STATIONS = 5;

const Sparkle: React.FC<{ x: number; y: number; s: number; o: number; rot: number }> = ({ x, y, s, o, rot }) => (
  <svg width={s * 2} height={s * 2} viewBox="-10 -10 20 20" style={{ position: "absolute", left: x - s, top: y - s, opacity: o, transform: `rotate(${rot}deg)`, overflow: "visible" }}>
    <path d="M0 -9 Q1 -1 9 0 Q1 1 0 9 Q-1 1 -9 0 Q-1 -1 0 -9 Z" fill={theme.colors.accent} style={{ filter: `drop-shadow(0 0 6px ${theme.colors.accentGlow})` }} />
  </svg>
);

export const SceneDive: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useAt();
  const e = EV.dive;
  const tToday = Math.max(0, at(e.today));
  const tInside = at(e.inside);
  const tEnter = at(e.enter);
  const tJourney = at(e.journey);
  const tStart = at(e.start);
  const tEnd = at(e.end);
  const tMystery = at(e.mystery);
  const tSolve = at(e.solve);

  // টানেল: ক্রমে দ্রুত
  const phase = frame * 0.0095 + 0.00005 * frame * frame;
  const boost = ramp(frame, tEnter, 24);
  const rings = Array.from({ length: 10 }).map((_, k) => {
    const p = (phase + k / 10) % 1;
    return { r: 14 * Math.pow(85, p), p, k };
  });

  // শিরোনাম গ্রুপ সরে ওপরে
  const mv = spring({ frame: frame - tJourney, fps, config: theme.spring.smooth });
  const groupY = interpolate(mv, [0, 1], [0, -292]);
  const groupS = interpolate(mv, [0, 1], [1, 0.62]);

  // লাইন-ড্র
  const trackIn = ramp(frame, tJourney + 4, 18);
  const prog = interpolate(frame, [tStart, tEnd], [0, 1], { easing: theme.ease.inOut, ...CL });
  const headX = PX0 + (PX1 - PX0) * prog;

  const burst = ramp(frame, tMystery, 26);
  const sparks = Array.from({ length: 7 }).map((_, i) => {
    const a = (i / 7) * Math.PI * 2 + 0.4;
    return { x: 960 + Math.cos(a) * (200 + 130 * burst), y: 800 + Math.sin(a) * (70 + 80 * burst), s: 9 + (i % 3) * 4, o: Math.sin(Math.PI * burst) * 0.95, rot: i * 25 + frame * 2 };
  });

  return (
    <AbsoluteFill>
      {/* টানেল */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <g transform="translate(960 540)">
          {rings.map(({ r, p, k }) => (
            <circle key={k} r={r} fill="none" stroke={k === 0 ? theme.colors.primary : theme.colors.text} strokeWidth={2 + p * 6} opacity={Math.pow(Math.sin(Math.PI * p), 1.4) * (k === 0 ? 0.55 : 0.2)} />
          ))}
          {Array.from({ length: 16 }).map((_, k) => {
            const a = (k / 16) * Math.PI * 2;
            const off = (frame * (10 + 8 * boost) + k * 83) % 760;
            const r0 = 240 + off;
            const len = 30 + 70 * boost;
            return (
              <line key={k} x1={Math.cos(a) * r0} y1={Math.sin(a) * r0} x2={Math.cos(a) * (r0 + len)} y2={Math.sin(a) * (r0 + len)} stroke={theme.colors.accent} strokeWidth={3} strokeLinecap="round" opacity={boost * 0.45 * Math.sin(Math.PI * (off / 760))} />
            );
          })}
        </g>
        <radialGradient id="scrim" cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor={theme.colors.bg} stopOpacity="0.75" />
          <stop offset="1" stopColor={theme.colors.bg} stopOpacity="0" />
        </radialGradient>
        <ellipse cx={960} cy={540} rx={760} ry={300} fill="url(#scrim)" opacity={1 - 0.7 * ramp(frame, tJourney, 20)} />
      </svg>

      {/* শিরোনাম গ্রুপ */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 404, display: "flex", flexDirection: "column", alignItems: "center", transform: `translateY(${groupY}px) scale(${groupS})`, transformOrigin: "50% 50%" }}>
        <WordReveal text="আজ আমরা" delay={tToday} per={4} size={62} kinds={{ 0: "dim", 1: "dim" }} justify="center" />
        <div style={{ display: "flex", columnGap: 38, justifyContent: "center" }}>
          <WordReveal text="ক্যামেরার ভেতরে" delay={tInside} per={4} size={136} />
          <WordReveal text="ঢুকে" delay={tEnter} per={4} size={136} kinds={{ 0: "hero" }} />
        </div>
      </div>

      {/* লাইন-ড্র: শুরু → শেষ */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, opacity: trackIn }}>
        <line x1={PX0} y1={PATH_Y} x2={PX1} y2={PATH_Y} stroke={theme.colors.line} strokeWidth={6} strokeLinecap="round" />
        <line x1={PX0} y1={PATH_Y} x2={headX} y2={PATH_Y} stroke={theme.colors.primary} strokeWidth={8} strokeLinecap="round" style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glow})` }} />
        {Array.from({ length: STATIONS }).map((_, i) => {
          const x = PX0 + ((PX1 - PX0) * (i + 1)) / (STATIONS + 1);
          const lit = headX >= x;
          return <circle key={i} cx={x} cy={PATH_Y} r={lit ? 10 : 7} fill={lit ? theme.colors.text : theme.colors.line} />;
        })}
        <circle cx={PX0} cy={PATH_Y} r={24} fill={frame >= tStart ? theme.colors.primary : theme.colors.bg} stroke={theme.colors.text} strokeWidth={4} />
        <circle cx={PX1} cy={PATH_Y} r={24} fill={prog > 0.985 ? theme.colors.accent : theme.colors.bg} stroke={theme.colors.text} strokeWidth={4} />
        <circle cx={headX} cy={PATH_Y} r={14} fill={theme.colors.white} opacity={prog > 0 && prog < 1 ? 1 : 0} style={{ filter: `drop-shadow(0 0 16px ${theme.colors.glow})` }} />
      </svg>
      <div style={{ position: "absolute", left: PX0 - 140, top: PATH_Y + 40, width: 280, display: "flex", justifyContent: "center" }}>
        <Entrance delay={tStart} y={26} from={0.8} config={theme.spring.bouncy}>
          <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 70, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text }}>শুরু</span>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: PX1 - 140, top: PATH_Y + 40, width: 280, display: "flex", justifyContent: "center" }}>
        <Entrance delay={tEnd} y={26} from={0.8} config={theme.spring.bouncy}>
          <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 70, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text }}>শেষ</span>
        </Entrance>
      </div>

      {/* রহস্য */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 724, display: "flex", justifyContent: "center", alignItems: "baseline", columnGap: 36 }}>
        <WordReveal text="সেই" delay={tMystery - 3} per={4} size={84} kinds={{ 0: "dim" }} />
        <WordReveal text="রহস্যটাই" delay={tMystery} per={4} size={156} kinds={{ 0: "hero" }} />
        <WordReveal text="বুঝব" delay={tSolve} per={4} size={84} />
      </div>
      {sparks.map((s, i) => (
        <Sparkle key={i} {...s} />
      ))}
    </AbsoluteFill>
  );
};
