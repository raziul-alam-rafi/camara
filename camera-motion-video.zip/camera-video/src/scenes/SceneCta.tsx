// সিন ৭ — Minimal Clean সমাপ্তি / CTA | cue 9
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV } from "../timeline";
import { useAt, useScene } from "../lib/scene";
import { CL, breathe, ramp, rampIn } from "../lib/anim";
import { Entrance, Pill, WordReveal } from "../components/Motion";
import { IconPlay } from "../components/Icons";

const RING = 330;

export const SceneCta: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { duration } = useScene();
  const at = useAt();
  const tClear = Math.max(0, at(EV.cta.clear));
  const tGo = at(EV.cta.go);
  const tStart = at(EV.cta.start);

  const draw = ramp(frame, tClear + 4, 34);
  const sweep = interpolate(frame, [tClear + 24, tClear + 52], [-0.4, 1.4], { easing: theme.ease.inOut, ...CL });
  const pop = spring({ frame: frame - tStart, fps, config: theme.spring.bouncy });
  const ripple = ramp(frame, tStart, 30);
  const out = rampIn(frame, duration - 9, 8);
  const R = 140;
  const circ = 2 * Math.PI * R;

  return (
    <AbsoluteFill style={{ opacity: 1 - out, transform: `scale(${1 - 0.03 * out})` }}>
      <div style={{ position: "absolute", top: 120, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Entrance delay={tClear} y={26}>
          <Pill size={50}>পানির মতো পরিষ্কার</Pill>
        </Entrance>
      </div>

      {/* পরিষ্কার লেন্স-রিং + প্লে */}
      <div style={{ position: "absolute", left: 960 - RING / 2, top: 440 - RING / 2, width: RING, height: RING, transform: `scale(${breathe(frame, 0.012, 24)})` }}>
        <svg width={RING} height={RING} viewBox="-165 -165 330 330" style={{ overflow: "visible" }}>
          <defs>
            <radialGradient id="ctaGlass" cx="50%" cy="40%" r="60%">
              <stop offset="0" stopColor={theme.colors.surfaceStrong} />
              <stop offset="1" stopColor={theme.colors.surface} />
            </radialGradient>
            <clipPath id="ctaClip">
              <circle r={R - 4} />
            </clipPath>
          </defs>
          <circle r={R} fill="url(#ctaGlass)" opacity={draw} />
          <circle r={R + 18} fill="none" stroke={theme.colors.line} strokeWidth={2} opacity={draw} />
          <circle
            r={R}
            fill="none"
            stroke={theme.colors.primary}
            strokeWidth={7}
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={circ * (1 - draw)}
            transform="rotate(-90)"
            style={{ filter: `drop-shadow(0 0 ${14 + 16 * pop}px ${theme.colors.glow})` }}
          />
          <g clipPath="url(#ctaClip)">
            <rect x={-60 + sweep * 330 - 165} y={-200} width={70} height={400} transform="rotate(20)" fill={theme.colors.white} opacity={0.2} />
          </g>
          <circle r={R + 18 + ripple * 90} fill="none" stroke={theme.colors.primary} strokeWidth={3} opacity={Math.sin(Math.PI * ripple) * 0.5} />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: ramp(frame, tClear + 20, 14), transform: `scale(${interpolate(pop, [0, 1], [1, 1.12])})` }}>
          <div style={{ marginLeft: 10 }}>
            <IconPlay size={118} color={theme.colors.text} fill={theme.colors.text} />
          </div>
        </div>
      </div>

      {/* হেডলাইন */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 676 }}>
        <WordReveal text="চলুন শুরু করা যাক" delay={tGo} per={3} size={144} justify="center" kinds={{ 1: "hero" }} />
      </div>
    </AbsoluteFill>
  );
};
