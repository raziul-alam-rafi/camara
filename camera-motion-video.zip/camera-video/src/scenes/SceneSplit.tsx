// সিন ৩ — Before / After Split | cue 4–5
import React from "react";
import { AbsoluteFill, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV } from "../timeline";
import { useAt } from "../lib/scene";
import { floatY, prng, ramp } from "../lib/anim";
import { Entrance, Pill, WordReveal } from "../components/Motion";
import { GlassCard } from "../components/GlassCard";
import { IconGlobe, IconPerson, IconPhoto, IconTree } from "../components/Icons";

const PANEL_TOP = 240;
const PANEL_H = 700;
const PANEL_W = 770;
const LX = 110;
const RX = 1040;

const WAVE_W = 690;
const WAVE_H = 230;
const waveY = (x: number, ph: number, amp: number) => {
  const v = Math.sin(x / 40 + ph) * 0.62 + Math.sin(x / 14 + ph * 1.7) * 0.22;
  const q = Math.round(v * 5) / 5; // ডিজিটাল ধাপ
  return WAVE_H / 2 - q * amp;
};

const TILES = [
  { Icon: IconPerson, label: "মানুষ" },
  { Icon: IconTree, label: "গাছ" },
  { Icon: IconGlobe, label: "পৃথিবী" },
];

export const SceneSplit: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useAt();
  const e = EV.split;
  const tHead1 = Math.max(0, at(e.head1) - 20);
  const tHead2 = at(e.head2);
  const tNone = at(e.none);
  const tLight = at(e.light);
  const tSignal = at(e.signal);
  const tSo = at(e.so);
  const tP = [at(e.p1), at(e.p2), at(e.p3)];

  // স্ট্রাইক ও ফ্রেম ফেড
  const strike = ramp(frame, tNone + 2, 14);
  const frameFade = ramp(frame, tNone + 22, 16);
  const leftDim = ramp(frame, tLight, 20);

  // সিগন্যাল
  const wavePrg = ramp(frame, tSignal, 26);
  const pulse = 1 + 0.28 * Math.max(0, Math.sin(Math.min(1, Math.max(0, (frame - tSo) / 30)) * Math.PI));
  const ph = frame * 0.09;
  let d = `M 0 ${waveY(0, ph, 78 * pulse)}`;
  const STEPX = 10;
  for (let x = STEPX; x <= WAVE_W; x += STEPX) {
    d += ` H ${x} V ${waveY(x, ph, 78 * pulse)}`;
  }

  // আলোর কণা
  const rnd = prng(11);
  const particles = Array.from({ length: 18 }).map((_, k) => ({ y0: 40 + rnd() * 150, s: 7 + rnd() * 8, sp: 0.007 + rnd() * 0.005, off: rnd() }));

  return (
    <AbsoluteFill>
      {/* শিরোনাম */}
      <div style={{ position: "absolute", top: 66, left: 0, right: 0, display: "flex", justifyContent: "center", columnGap: 26 }}>
        <WordReveal text="ক্যামেরার ভেতরে" delay={tHead1} per={4} size={84} />
        <WordReveal text="কোনো" delay={tHead2} per={4} size={84} />
        <WordReveal text="ছবিই থাকে না" delay={tNone} per={4} size={84} kinds={{ 0: "hero", 1: "hero", 2: "hero" }} />
      </div>

      {/* ডিভাইডার */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <linearGradient id="div" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={theme.colors.line} stopOpacity="0" />
            <stop offset="0.5" stopColor={theme.colors.text} stopOpacity="0.5" />
            <stop offset="1" stopColor={theme.colors.line} stopOpacity="0" />
          </linearGradient>
        </defs>
        <line x1={960} y1={PANEL_TOP} x2={960} y2={PANEL_TOP + PANEL_H} stroke="url(#div)" strokeWidth={3} opacity={ramp(frame, 4, 20)} />
      </svg>

      {/* বাম প্যানেল — আপনার দেখা */}
      <div style={{ position: "absolute", left: LX, top: PANEL_TOP + floatY(frame, 3, 36), opacity: 1 - 0.5 * leftDim }}>
        <Entrance delay={tHead1 + 4} y={50} from={0.96}>
          <GlassCard width={PANEL_W} height={PANEL_H} radius={theme.radius.lg}>
            <div style={{ position: "absolute", left: 34, top: 30 }}>
              <Pill size={38}>আপনার দেখা</Pill>
            </div>
            <div style={{ position: "absolute", left: 0, right: 0, top: 226, display: "flex", justifyContent: "center", gap: 30 }}>
              {TILES.map(({ Icon, label }, i) => (
                <Entrance key={i} delay={tP[i]} y={46} from={0.86} config={theme.spring.bouncy}>
                  <GlassCard width={216} height={290} radius={theme.radius.md} style={{ background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})` }}>
                    <div style={{ position: "absolute", left: 0, right: 0, top: 36, display: "flex", justifyContent: "center", transform: `translateY(${floatY(frame, 3, 28, i)}px)` }}>
                      <Icon size={128} color={theme.colors.text} stroke={1.5} />
                    </div>
                    <div style={{ position: "absolute", left: 0, right: 0, bottom: 28, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 54, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text }}>
                      {label}
                    </div>
                  </GlassCard>
                </Entrance>
              ))}
            </div>
          </GlassCard>
        </Entrance>
      </div>

      {/* ডান প্যানেল — ক্যামেরার ভেতরে */}
      <div style={{ position: "absolute", left: RX, top: PANEL_TOP + floatY(frame, 3, 36, 1.5) }}>
        <Entrance delay={tHead1 + 8} y={50} from={0.96}>
          <GlassCard width={PANEL_W} height={PANEL_H} radius={theme.radius.lg} active={ramp(frame, tSignal, 12) * (1 - ramp(frame, tSignal + 70, 20) * 0.6)}>
            <div style={{ position: "absolute", left: 34, top: 30 }}>
              <Pill size={38} tone={frame >= tSignal ? "hero" : "dim"}>
                ক্যামেরার ভেতরে
              </Pill>
            </div>

            {/* খালি ফ্রেম + স্ট্রাইক */}
            <div style={{ position: "absolute", left: 0, right: 0, top: 170, display: "flex", justifyContent: "center", opacity: 1 - frameFade, transform: `scale(${1 - 0.1 * frameFade})` }}>
              <div style={{ position: "relative", width: 400, height: 320, borderRadius: 40, border: `3px dashed ${theme.colors.textDim}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <IconPhoto size={170} color={theme.colors.textDim} stroke={1.4} />
                <svg width={400} height={320} style={{ position: "absolute", inset: -3 }}>
                  <line x1={40} y1={34} x2={40 + 320 * strike} y2={34 + 252 * strike} opacity={strike > 0.02 ? 1 : 0} stroke={theme.colors.primary} strokeWidth={12} strokeLinecap="round" style={{ filter: `drop-shadow(0 0 16px ${theme.colors.glow})` }} />
                </svg>
              </div>
            </div>

            {/* আলো + সিগন্যাল */}
            <div style={{ position: "absolute", left: 40, top: 200, width: WAVE_W, height: WAVE_H + 60 }}>
              {frame >= tLight &&
                particles.map((p, k) => {
                  const ph2 = (frame * p.sp + p.off) % 1;
                  const x = ph2 * WAVE_W;
                  const wy = waveY(x, ph, 78) + 30;
                  const y = p.y0 * (1 - ph2 * ph2) + wy * ph2 * ph2 - 20;
                  const vis = ramp(frame, tLight, 10);
                  return (
                    <div
                      key={k}
                      style={{
                        position: "absolute",
                        left: x,
                        top: y,
                        width: p.s,
                        height: p.s,
                        borderRadius: "50%",
                        background: theme.colors.accent,
                        opacity: Math.sin(Math.PI * ph2) * 0.9 * vis,
                        boxShadow: `0 0 14px ${theme.colors.accentGlow}`,
                      }}
                    />
                  );
                })}
              <svg width={WAVE_W} height={WAVE_H + 60} style={{ position: "absolute", left: 0, top: 30, overflow: "visible" }}>
                <defs>
                  <clipPath id="waveclip">
                    <rect x={0} y={-20} width={WAVE_W * wavePrg} height={WAVE_H + 40} />
                  </clipPath>
                </defs>
                <g clipPath="url(#waveclip)">
                  <path d={d} fill="none" stroke={theme.colors.primary} strokeWidth={6} strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glow})` }} />
                </g>
              </svg>
            </div>
            <div style={{ position: "absolute", left: 40, top: 520 }}>
              <Entrance delay={tLight} y={30} from={0.8} config={theme.spring.bouncy}>
                <Pill size={46} tone="accent">
                  আলো
                </Pill>
              </Entrance>
            </div>
            <div style={{ position: "absolute", left: 40, top: 608 }}>
              <Entrance delay={tSignal} y={30} from={0.8} config={theme.spring.bouncy}>
                <Pill size={46} tone="hero">
                  ইলেকট্রনিক সিগন্যাল
                </Pill>
              </Entrance>
            </div>
          </GlassCard>
        </Entrance>
      </div>
    </AbsoluteFill>
  );
};
