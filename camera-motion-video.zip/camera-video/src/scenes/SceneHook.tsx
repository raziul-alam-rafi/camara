// সিন ১ — হুক (Kinetic Typography + লেন্স হিরো ভিজ্যুয়াল) | cue 1
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV } from "../timeline";
import { useAt } from "../lib/scene";
import { CL, breathe, floatY, ramp } from "../lib/anim";
import { Entrance, Pill, WordReveal } from "../components/Motion";
import { Lens } from "../components/Lens";
import { IconCamera } from "../components/Icons";

const LENS_X = 1480;
const LENS_Y = 540;
const LENS_SIZE = 620;
const BEAMS = [330, 435, 540, 645, 750];

export const SceneHook: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useAt();
  const tLabel = Math.max(0, at(EV.hook.label));
  const tShutter = at(EV.hook.shutter);
  const tTitle = at(EV.hook.title);
  const tEmph = at(EV.hook.emph);
  const tAsk = at(EV.hook.ask);

  // লেন্স এন্ট্রি
  const lp = spring({ frame, fps, config: theme.spring.bouncy });
  const lensScale = interpolate(lp, [0, 1], [0.55, 1]) * breathe(frame, 0.012, 24);
  const lensRot = interpolate(spring({ frame, fps, config: theme.spring.smooth }), [0, 1], [-50, 0]);
  // শাটার ব্লিঙ্ক + ফ্ল্যাশ
  const blink = interpolate(frame, [tShutter, tShutter + 4, tShutter + 18], [0, 1, 0], { easing: theme.ease.out, ...CL });
  const flash = interpolate(frame, [tShutter, tShutter + 3, tShutter + 12], [0, 1, 0], { easing: theme.ease.out, ...CL });
  const open = interpolate(lp, [0, 1], [0.1, 1]) * (1 - 0.82 * blink);
  const core = 0.45 + 0.4 * flash + 0.15 * Math.sin(frame / 18);

  // কীওয়ার্ড আন্ডারলাইন
  const under = ramp(frame, tEmph + 8, 18);

  return (
    <AbsoluteFill>
      {/* আলোর রশ্মি লেন্সের দিকে ঢুকছে */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <linearGradient id="beam" gradientUnits="userSpaceOnUse" x1="1030" y1="0" x2="1210" y2="0">
            <stop offset="0" stopColor={theme.colors.accent} stopOpacity="0" />
            <stop offset="1" stopColor={theme.colors.accent} stopOpacity="0.95" />
          </linearGradient>
        </defs>
        {BEAMS.map((y0, i) => {
          const y1 = LENS_Y + (y0 - LENS_Y) * 0.32;
          const p = ramp(frame, 3 + i * 4, 26);
          const prog = ((frame * 0.012 + i * 0.21) % 1) * p;
          const dx = 1030 + 180 * prog, dy = y0 + (y1 - y0) * prog;
          return (
            <g key={i} opacity={Math.min(1, p * 2)}>
              <line x1={1030} y1={y0} x2={1030 + 180 * p} y2={y0 + (y1 - y0) * p} stroke="url(#beam)" strokeWidth={4} strokeLinecap="round" />
              <circle cx={dx} cy={dy} r={5} fill={theme.colors.accent} opacity={0.9 * Math.sin(Math.PI * prog)} />
            </g>
          );
        })}
      </svg>

      {/* লেন্স */}
      <div
        style={{
          position: "absolute",
          left: LENS_X - LENS_SIZE / 2,
          top: LENS_Y - LENS_SIZE / 2 + floatY(frame, 6, 34),
          width: LENS_SIZE,
          height: LENS_SIZE,
          opacity: Math.min(1, lp * 1.6),
          transform: `scale(${lensScale}) rotate(${lensRot}deg)`,
          filter: `drop-shadow(0 40px 70px rgba(0,0,0,0.55))`,
        }}
      >
        <Lens size={LENS_SIZE} open={open} spin={frame * 0.4} core={core} id="hook" />
      </div>

      {/* টেক্সট ব্লক */}
      <div style={{ position: "absolute", left: 130, top: 222, width: 1000 }}>
        <Entrance delay={tLabel} y={30}>
          <Pill size={40} icon={<IconCamera size={44} color={theme.colors.textDim} />}>
            আপনি যখন একটা ছবি তোলেন
          </Pill>
        </Entrance>
        <div style={{ marginTop: 34 }}>
          <WordReveal text="ক্যামেরার ভেতরে" delay={tTitle} per={4} size={156} />
          <div style={{ display: "flex", columnGap: 42, alignItems: "flex-start" }}>
            <WordReveal text="আসলে" delay={tTitle + 12} per={4} size={156} />
            <div style={{ position: "relative" }}>
              <WordReveal text="কী ঘটে?" delay={tEmph} per={5} size={156} kinds={{ 0: "hero", 1: "hero" }} />
              <div
                style={{
                  position: "absolute",
                  left: 0,
                  bottom: 14,
                  height: 8,
                  width: "100%",
                  borderRadius: 8,
                  background: theme.colors.accent,
                  transformOrigin: "0% 50%",
                  transform: `scaleX(${under})`,
                  opacity: 0.9,
                  boxShadow: `0 0 24px ${theme.colors.accentGlow}`,
                }}
              />
            </div>
          </div>
        </div>
        <div style={{ marginTop: 22 }}>
          <Entrance delay={tAsk} y={26} from={0.8} config={theme.spring.bouncy}>
            <Pill size={46} tone="accent">
              জানেন?
            </Pill>
          </Entrance>
        </div>
      </div>

      {/* শাটার ফ্ল্যাশ (সংযত) */}
      <AbsoluteFill style={{ backgroundColor: theme.colors.white, opacity: 0.16 * flash, pointerEvents: "none" }} />
    </AbsoluteFill>
  );
};
