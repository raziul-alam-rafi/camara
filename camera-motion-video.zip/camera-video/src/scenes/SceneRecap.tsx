// সিন ৬ — Checklist Recap Grid | cue 8
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { EV, recapSec } from "../timeline";
import { useAt } from "../lib/scene";
import { floatY, ramp } from "../lib/anim";
import { Entrance, WordReveal } from "../components/Motion";
import { GlassCard } from "../components/GlassCard";
import { IconCheck } from "../components/Icons";

const ITEMS = ["আলো ধরা", "বিদ্যুতে রূপান্তর", "কোটি কোটি হিসাব", "মুখ, আকাশ, গাছ চেনা"];
const CW = 820;
const CH = 250;
const POS = [
  { x: 110, y: 290 },
  { x: 990, y: 290 },
  { x: 110, y: 590 },
  { x: 990, y: 590 },
];

export const SceneRecap: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const at = useAt();
  const tWord = at(EV.recap.word);
  const tClear = at(EV.recap.clear);

  return (
    <AbsoluteFill>
      {/* পানির মতো রিপল */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <g transform="translate(960 560)">
          {[0, 1, 2].map((k) => {
            const p = ramp(frame, tClear + k * 7, 46);
            return <circle key={k} r={80 + p * 820} fill="none" stroke={theme.colors.text} strokeWidth={3} opacity={Math.sin(Math.PI * p) * 0.28} />;
          })}
        </g>
      </svg>

      {/* শিরোনাম */}
      <div style={{ position: "absolute", top: 96, left: 0, right: 0, display: "flex", justifyContent: "center", columnGap: 30 }}>
        <WordReveal text="ছবি তোলার সম্পূর্ণ" delay={4} per={4} size={96} />
        <WordReveal text="মেকানিজম" delay={tWord} per={4} size={96} kinds={{ 0: "hero" }} />
      </div>

      {/* কার্ড */}
      {ITEMS.map((label, i) => {
        const tTick = at(recapSec(i));
        const flash = (1 - ramp(frame, tTick + 8, 22)) * ramp(frame, tTick, 6);
        const tickP = spring({ frame: frame - tTick, fps, config: theme.spring.bouncy });
        const done = frame >= tTick;
        return (
          <div key={i} style={{ position: "absolute", left: POS[i].x, top: POS[i].y, transform: `translateY(${floatY(frame, 3, 34, i * 1.1)}px)` }}>
            <Entrance delay={6 + i * 5} y={54} from={0.92}>
              <GlassCard width={CW} height={CH} radius={theme.radius.md} active={flash}>
                <div style={{ position: "absolute", right: 34, top: 20, fontFamily: theme.fonts.display, fontSize: 32, fontWeight: theme.weight.strong, color: theme.colors.textDim, letterSpacing: 0 }}>0{i + 1}</div>
                <div
                  style={{
                    position: "absolute",
                    left: 44,
                    top: (CH - 132) / 2,
                    width: 132,
                    height: 132,
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    border: `3px solid ${done ? theme.colors.primary : theme.colors.line}`,
                    background: done ? theme.colors.primary : "transparent",
                    boxShadow: done ? `0 0 ${40 * flash + 10}px ${theme.colors.glow}` : undefined,
                    transform: `scale(${done ? interpolate(tickP, [0, 1], [0.7, 1]) : 1})`,
                  }}
                >
                  <IconCheck size={78} color={theme.colors.white} stroke={3} progress={done ? ramp(frame, tTick + 2, 10) : 0} />
                </div>
                <div
                  style={{
                    position: "absolute",
                    left: 214,
                    right: 40,
                    top: 0,
                    bottom: 0,
                    display: "flex",
                    alignItems: "center",
                    fontFamily: theme.fonts.display,
                    fontWeight: theme.weight.hero,
                    fontSize: 58,
                    lineHeight: 1.3,
                    letterSpacing: 0,
                    color: theme.colors.text,
                  }}
                >
                  {label}
                </div>
              </GlassCard>
            </Entrance>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};
