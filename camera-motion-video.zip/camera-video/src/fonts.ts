import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// বাংলা যুক্তাক্ষর ঠিক আসে এমন ফন্ট; হিরো টেক্সটে সর্বোচ্চ ওজন (700)
export const { fontFamily: hindSiliguri } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});
