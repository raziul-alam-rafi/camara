// theme.ts — সব রং, ইজিং, spring, ফন্ট এখানে। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
// স্কিম: Midnight Lens (গাঢ় নীল ব্যাকগ্রাউন্ড + নীল হিরো + অ্যাম্বার অ্যাকসেন্ট)
import { Easing } from "remotion";
import { hindSiliguri } from "./fonts";

const stack = `${hindSiliguri}, "Hind Siliguri", "Noto Sans Bengali", "Noto Sans", sans-serif`;

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#121A33",
    primary: "#4F8CFF", // হিরো
    accent: "#FFB84D", // অ্যাকসেন্ট (আলো)
    text: "#F4F7FF",
    textDim: "#9FB0D6",
    surface: "rgba(244,247,255,0.06)",
    surfaceStrong: "rgba(244,247,255,0.11)",
    line: "rgba(244,247,255,0.16)",
    lineSoft: "rgba(244,247,255,0.08)",
    glow: "rgba(79,140,255,0.45)",
    accentGlow: "rgba(255,184,77,0.40)",
    shade: "rgba(3,6,16,0.55)",
    white: "#FFFFFF",
  },
  fonts: { display: stack, body: stack },
  weight: { hero: 700, strong: 600, body: 500 },
  radius: { sm: 18, md: 30, lg: 42 },
  shadow: {
    card: "0 36px 80px -28px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.12)",
    soft: "0 18px 40px -18px rgba(0,0,0,0.6)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;

export type Theme = typeof theme;
