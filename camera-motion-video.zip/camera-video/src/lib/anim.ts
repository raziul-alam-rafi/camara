import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** spring প্রগ্রেস (delay = সিন-লোকাল ফ্রেম) */
export const useSpring = (delay: number, config: { damping: number; stiffness: number; mass: number } = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** ইজড 0→1 র‍্যাম্প (কখনো linear নয়) */
export const ramp = (frame: number, start: number, dur: number, easing = theme.ease.out) =>
  interpolate(frame, [start, start + Math.max(1, dur)], [0, 1], { easing, ...CL });

/** দ্রুততর এক্সিট র‍্যাম্প */
export const rampIn = (frame: number, start: number, dur: number) => ramp(frame, start, dur, theme.ease.in);

/** ডিটারমিনিস্টিক PRNG (0..1) */
export const prng = (seed: number) => {
  let s = seed | 0;
  return () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

/** idle breathing */
export const breathe = (frame: number, amp = 0.015, period = 22) => 1 + Math.sin(frame / period) * amp;
export const floatY = (frame: number, amp = 4, period = 30, phase = 0) => Math.sin(frame / period + phase) * amp;
