import React, { createContext, useContext } from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { LEAD, OVERLAP } from "../config";
import { theme } from "../theme";
import { sec2f } from "../timeline";
import { CL } from "./anim";

type Ctx = { from: number; duration: number; index: number; last: boolean };
export const SceneCtx = createContext<Ctx>({ from: 0, duration: 1, index: 0, last: false });
export const useScene = () => useContext(SceneCtx);

/** SRT সেকেন্ড → সিন-লোকাল ফ্রেম (LEAD ফ্রেম আগে ঢোকে) */
export const useAt = () => {
  const { from } = useScene();
  return (sec: number) => sec2f(sec) - LEAD - from;
};

/** সিন র‍্যাপার: ট্রানজিশন-ইন (স্কেল) ও দ্রুত এক্সিট (স্কেল-থ্রু + ব্লার + ফেড) */
export const SceneShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const { duration, last, index } = useScene();
  const enter = interpolate(frame, [0, 16], [0, 1], { easing: theme.ease.out, ...CL });
  const exit = last
    ? 0
    : interpolate(frame, [duration - OVERLAP, duration], [0, 1], { easing: theme.ease.in, ...CL });
  const scale = (index === 0 ? 1 : 0.955 + 0.045 * enter) * (1 + 0.07 * exit);
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - exit,
        transform: `scale(${scale})`,
        filter: exit > 0.01 ? `blur(${exit * 10}px)` : undefined,
        willChange: "transform, opacity",
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
