import React from "react";
import { theme } from "../theme";

/** ক্যামেরা লেন্স (SVG) — open = আইরিস খোলা (0..1), spin = ঘূর্ণন (ডিগ্রি), core = ভেতরের আলো (0..1) */
export const Lens: React.FC<{ size: number; open?: number; spin?: number; core?: number; id?: string }> = ({
  size,
  open = 1,
  spin = 0,
  core = 1,
  id = "lens",
}) => {
  const c = theme.colors;
  const a = 22 + Math.max(0, open) * 70;
  const R = 148;
  const n = 6;
  const V = Array.from({ length: n }).map((_, k) => {
    const t = (k * 2 * Math.PI) / n;
    const t2 = t + 1.3;
    return { vx: a * Math.cos(t), vy: a * Math.sin(t), px: R * Math.cos(t2), py: R * Math.sin(t2) };
  });
  return (
    <svg width={size} height={size} viewBox="-230 -230 460 460" style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`${id}-body`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={c.bgAlt} />
          <stop offset="1" stopColor={c.bg} />
        </linearGradient>
        <linearGradient id={`${id}-ring`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={c.text} stopOpacity="0.75" />
          <stop offset="0.5" stopColor={c.textDim} stopOpacity="0.25" />
          <stop offset="1" stopColor={c.text} stopOpacity="0.5" />
        </linearGradient>
        <radialGradient id={`${id}-glass`} cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor={c.primary} stopOpacity="0.4" />
          <stop offset="0.7" stopColor={c.bgAlt} stopOpacity="0.9" />
          <stop offset="1" stopColor={c.bg} />
        </radialGradient>
        <radialGradient id={`${id}-core`} cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor={c.white} stopOpacity="0.95" />
          <stop offset="0.25" stopColor={c.accent} stopOpacity="0.95" />
          <stop offset="1" stopColor={c.accent} stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle r="214" fill={`url(#${id}-body)`} stroke={`url(#${id}-ring)`} strokeWidth="5" />
      <g transform={`rotate(${-spin * 0.5})`} stroke={c.line} strokeWidth="2.4" strokeLinecap="round">
        {Array.from({ length: 60 }).map((_, i) => {
          const t = (i * Math.PI * 2) / 60;
          return <line key={i} x1={Math.cos(t) * 196} y1={Math.sin(t) * 196} x2={Math.cos(t) * (i % 5 === 0 ? 207 : 202)} y2={Math.sin(t) * (i % 5 === 0 ? 207 : 202)} />;
        })}
      </g>
      <circle r="176" fill="none" stroke={c.primary} strokeWidth="3" style={{ filter: `drop-shadow(0 0 12px ${c.glow})` }} />
      <circle r="158" fill={`url(#${id}-glass)`} stroke={c.lineSoft} strokeWidth="2" />
      <g transform={`rotate(${spin})`}>
        {V.map((p, k) => {
          const q = V[(k + 1) % n];
          return (
            <polygon
              key={k}
              points={`${p.vx},${p.vy} ${p.px},${p.py} ${q.px},${q.py} ${q.vx},${q.vy}`}
              fill={k % 2 === 0 ? c.surfaceStrong : c.surface}
              stroke={c.line}
              strokeWidth="1.6"
              strokeLinejoin="round"
            />
          );
        })}
        <polygon points={V.map((p) => `${p.vx},${p.vy}`).join(" ")} fill={c.bg} stroke={c.line} strokeWidth="1.6" />
      </g>
      <circle r={Math.max(8, a * 1.15)} fill={`url(#${id}-core)`} opacity={0.35 + 0.65 * core} />
      <ellipse cx="-66" cy="-84" rx="64" ry="20" transform="rotate(-38 -66 -84)" fill={c.white} opacity="0.13" />
    </svg>
  );
};
