import React from "react";
import { theme } from "../theme";

/** গ্লসি/গ্লাস কার্ড। active (0..1) = হিরো বর্ডার + গ্লো (প্রতি ফ্রেমে একটিই) */
export const GlassCard: React.FC<{
  width?: number | string;
  height?: number | string;
  radius?: number;
  active?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ width, height, radius = theme.radius.md, active = 0, style, children }) => (
  <div
    style={{
      position: "relative",
      width,
      height,
      borderRadius: radius,
      background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
      border: `1.5px solid ${theme.colors.line}`,
      boxShadow: theme.shadow.card,
      ...style,
    }}
  >
    <div
      style={{
        position: "absolute",
        inset: 0,
        borderRadius: radius,
        background: "linear-gradient(180deg, rgba(255,255,255,0.10), transparent 34%)",
        pointerEvents: "none",
      }}
    />
    <div
      style={{
        position: "absolute",
        inset: -1.5,
        borderRadius: radius,
        border: `2.5px solid ${theme.colors.primary}`,
        boxShadow: `0 0 60px ${theme.colors.glow}, inset 0 0 40px ${theme.colors.primary}1f`,
        opacity: active,
        pointerEvents: "none",
      }}
    />
    {children}
  </div>
);
