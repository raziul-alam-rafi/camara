import React from "react";
import { theme } from "../theme";

type P = { size?: number; color?: string; stroke?: number; progress?: number; fill?: string };
const base = (size: number, color: string, stroke: number): React.SVGProps<SVGSVGElement> => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: color,
  strokeWidth: stroke,
  strokeLinecap: "round",
  strokeLinejoin: "round",
});
const D = theme.colors.text;

export const IconLight: React.FC<P> = ({ size = 64, color = D, stroke = 1.7 }) => (
  <svg {...base(size, color, stroke)}>
    <circle cx="12" cy="12" r="3.8" />
    {Array.from({ length: 8 }).map((_, i) => {
      const a = (i * Math.PI) / 4;
      return <line key={i} x1={12 + Math.cos(a) * 7.2} y1={12 + Math.sin(a) * 7.2} x2={12 + Math.cos(a) * 10.4} y2={12 + Math.sin(a) * 10.4} />;
    })}
  </svg>
);
export const IconBolt: React.FC<P> = ({ size = 64, color = D, stroke = 1.7, fill = "none" }) => (
  <svg {...base(size, color, stroke)}>
    <path d="M13.2 2.4 L4.6 13.6 H11 L10.2 21.6 L19.4 9.8 H13 Z" fill={fill} />
  </svg>
);
export const IconGrid: React.FC<P> = ({ size = 64, color = D, stroke = 1.6 }) => (
  <svg {...base(size, color, stroke)}>
    {[0, 1, 2].flatMap((r) =>
      [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={3.2 + c * 6.7} y={3.2 + r * 6.7} width="4.6" height="4.6" rx="1.2" />),
    )}
  </svg>
);
export const IconPhoto: React.FC<P> = ({ size = 64, color = D, stroke = 1.7 }) => (
  <svg {...base(size, color, stroke)}>
    <rect x="3" y="4.5" width="18" height="15" rx="3" />
    <circle cx="9" cy="10" r="1.8" />
    <polyline points="3.4,17 9,12.4 13.6,16 16.6,13.4 20.6,17" />
  </svg>
);
export const IconPerson: React.FC<P> = ({ size = 64, color = D, stroke = 1.7 }) => (
  <svg {...base(size, color, stroke)}>
    <circle cx="12" cy="8" r="4" />
    <path d="M4.2 21 C4.2 16.8 7.6 14.2 12 14.2 C16.4 14.2 19.8 16.8 19.8 21" />
  </svg>
);
export const IconTree: React.FC<P> = ({ size = 64, color = D, stroke = 1.7 }) => (
  <svg {...base(size, color, stroke)}>
    <path d="M12 2.8 L6.4 10.4 H9.2 L4.8 16.6 H19.2 L14.8 10.4 H17.6 Z" />
    <line x1="12" y1="16.6" x2="12" y2="21.2" />
  </svg>
);
export const IconGlobe: React.FC<P> = ({ size = 64, color = D, stroke = 1.7 }) => (
  <svg {...base(size, color, stroke)}>
    <circle cx="12" cy="12" r="9" />
    <ellipse cx="12" cy="12" rx="4" ry="9" />
    <line x1="3" y1="12" x2="21" y2="12" />
    <path d="M4.8 7.4 Q12 10 19.2 7.4" />
    <path d="M4.8 16.6 Q12 14 19.2 16.6" />
  </svg>
);
export const IconClock: React.FC<P> = ({ size = 40, color = D, stroke = 1.9 }) => (
  <svg {...base(size, color, stroke)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7 V12 L15.6 14.2" />
  </svg>
);
export const IconCheck: React.FC<P> = ({ size = 40, color = D, stroke = 2.6, progress = 1 }) => (
  <svg {...base(size, color, stroke)}>
    <polyline points="5,12.6 10,17.4 19,7" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress} />
  </svg>
);
export const IconPlay: React.FC<P> = ({ size = 40, color = D, fill = D }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color} strokeWidth={1.2} strokeLinejoin="round">
    <polygon points="8.4,5 19,12 8.4,19" />
  </svg>
);
export const IconCamera: React.FC<P> = ({ size = 40, color = D, stroke = 1.8 }) => (
  <svg {...base(size, color, stroke)}>
    <path d="M4 8 H7.4 L9 5.6 H15 L16.6 8 H20 V19 H4 Z" />
    <circle cx="12" cy="13.2" r="3.4" />
  </svg>
);
