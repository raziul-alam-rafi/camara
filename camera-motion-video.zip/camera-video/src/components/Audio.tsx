import React, { useEffect, useState } from "react";
import { Audio, Sequence, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { SFX, SFX_LEN } from "../timeline";
import { VOICEOVER_IN_PREVIEW, VOICEOVER_IN_RENDER } from "../config";

/** SFX লেয়ার — Studio প্রিভিউ ও রেন্ডার দুটোতেই শোনা যায় (public/sfx/*.wav) */
export const SfxLayer: React.FC = () => (
  <>
    {SFX.map((s, i) => (
      <Sequence key={i} from={s.frame} durationInFrames={Math.ceil((SFX_LEN[s.name] / s.rate + 0.12) * 30)} name={`sfx-${s.name}`}>
        <Audio src={staticFile(`sfx/${s.name}.wav`)} volume={s.volume} playbackRate={s.rate} />
      </Sequence>
    ))}
  </>
);

/** public/voiceover.mp3 থাকলে বাজে, না থাকলে নীরবে বাদ। ফ্ল্যাগ: src/config.ts */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const enabled = isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_PREVIEW;
  const [found, setFound] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    const handle = delayRender("voiceover.mp3 আছে কিনা দেখা হচ্ছে");
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((res) => {
        const type = res.headers.get("content-type") || "";
        if (!cancelled && res.ok && type.includes("audio")) setFound(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => {
      cancelled = true;
    };
  }, [enabled]);

  if (!enabled || !found) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
