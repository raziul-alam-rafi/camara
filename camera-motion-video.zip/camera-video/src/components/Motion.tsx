import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { CL, ramp } from "../lib/anim";

type SpringCfg = { damping: number; stiffness: number; mass: number };

/** ফেড + রাইজ + স্কেল (৩টি প্রপার্টি একসাথে) */
export const Entrance: React.FC<{
  delay?: number;
  y?: number;
  from?: number;
  config?: SpringCfg;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, y = 40, from = 0.94, config = theme.spring.smooth, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config });
  return (
    <div
      style={{
        opacity: Math.min(1, Math.max(0, p * 1.4)),
        transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** গ্রেডিয়েন্ট কীওয়ার্ড (শুধু একটি শব্দ, হিরো) */
export const heroText = (glow = true): React.CSSProperties => ({
  background: `linear-gradient(100deg, ${theme.colors.primary} 0%, ${theme.colors.text} 120%)`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
  filter: glow ? `drop-shadow(0 0 28px ${theme.colors.glow})` : undefined,
});
export const accentText = (): React.CSSProperties => ({
  background: `linear-gradient(100deg, ${theme.colors.accent} 0%, ${theme.colors.text} 130%)`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
  filter: `drop-shadow(0 0 24px ${theme.colors.accentGlow})`,
});

export type WordKind = "hero" | "accent" | "dim";

/**
 * শব্দ-ধরে স্ট্যাগার্ড রিভিল — বিভাজন শুধু স্পেসে (বাংলা যুক্তাক্ষর কখনো ভাঙে না)।
 * letterSpacing সবসময় 0।
 */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  kinds?: Record<number, WordKind>;
  justify?: "flex-start" | "center" | "flex-end";
  gap?: number;
  config?: SpringCfg;
  /** শব্দ আসার পর হিরো শব্দে ছোট পপ */
  pop?: boolean;
  style?: React.CSSProperties;
}> = ({
  text,
  delay = 0,
  per = 4,
  size,
  weight = theme.weight.hero,
  color = theme.colors.text,
  kinds = {},
  justify = "flex-start",
  gap,
  config = theme.spring.snappy,
  pop = true,
  style,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: justify,
        columnGap: gap ?? Math.round(size * 0.26),
        rowGap: 0,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.34,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const d = delay + i * per;
        const p = spring({ frame: frame - d, fps, config });
        const kind = kinds[i];
        const bump = kind && pop ? 1 + 0.07 * Math.max(0, Math.sin(Math.min(1, Math.max(0, (frame - d) / 16)) * Math.PI)) : 1;
        const base: React.CSSProperties =
          kind === "hero" ? heroText() : kind === "accent" ? accentText() : kind === "dim" ? { color: theme.colors.textDim } : {};
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, Math.max(0, p * 1.5)),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1]) * bump})`,
              ...base,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** হাইলাইট সুইপ: টেক্সটের পেছনে রং বাঁ→ডানে টানা */
export const HighlightSweep: React.FC<{
  delay: number;
  dur?: number;
  color?: string;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ delay, dur = 14, color = theme.colors.primary, children, style }) => {
  const frame = useCurrentFrame();
  const p = ramp(frame, delay, dur);
  return (
    <span style={{ position: "relative", display: "inline-block", ...style }}>
      <span
        style={{
          position: "absolute",
          left: -12,
          right: -12,
          top: "16%",
          bottom: "10%",
          borderRadius: 14,
          background: `${color}40`,
          transformOrigin: "0% 50%",
          transform: `scaleX(${p})`,
        }}
      />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** লাইন মাস্ক রিভিল (নিচ থেকে উঠে আসা) */
export const MaskLine: React.FC<{ delay: number; children: React.ReactNode; pad?: number; style?: React.CSSProperties }> = ({
  delay,
  children,
  pad = 14,
  style,
}) => {
  const frame = useCurrentFrame();
  const p = ramp(frame, delay, 20);
  return (
    <div style={{ overflow: "hidden", paddingTop: pad, paddingBottom: pad, marginTop: -pad, marginBottom: -pad, ...style }}>
      <div style={{ transform: `translateY(${(1 - p) * 110}%)`, opacity: Math.min(1, p * 3) }}>{children}</div>
    </div>
  );
};

/** ছোট ক্যাপসুল লেবেল */
export const Pill: React.FC<{
  size?: number;
  tone?: "dim" | "hero" | "accent";
  icon?: React.ReactNode;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ size = 40, tone = "dim", icon, children, style }) => {
  const border = tone === "hero" ? theme.colors.primary : tone === "accent" ? theme.colors.accent : theme.colors.line;
  const color = tone === "dim" ? theme.colors.textDim : theme.colors.text;
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 14,
        padding: `${Math.round(size * 0.22)}px ${Math.round(size * 0.55)}px`,
        borderRadius: 999,
        border: `1.5px solid ${border}`,
        background: theme.colors.surface,
        fontFamily: theme.fonts.display,
        fontWeight: theme.weight.strong,
        fontSize: size,
        lineHeight: 1.3,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {icon}
      <span>{children}</span>
    </div>
  );
};

export { CL };
