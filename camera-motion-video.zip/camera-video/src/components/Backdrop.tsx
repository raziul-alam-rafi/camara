import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SCENES } from "../timeline";

// সিন-ভিত্তিক আলোর ফোকাস (পজিশন), রং নয়
const FOCUS = [
  { ax: 1480, ay: 520, bx: 200, by: 920 }, // hook
  { ax: 960, ay: 640, bx: 320, by: 160 }, // flow
  { ax: 960, ay: 560, bx: 1700, by: 180 }, // split
  { ax: 1360, ay: 540, bx: 300, by: 900 }, // detect
  { ax: 960, ay: 540, bx: 960, by: 560 }, // dive
  { ax: 960, ay: 520, bx: 220, by: 200 }, // recap
  { ax: 960, ay: 430, bx: 1500, by: 920 }, // cta
];

const KEY_F: number[] = [0];
const KEY_AX: number[] = [FOCUS[0].ax];
const KEY_AY: number[] = [FOCUS[0].ay];
const KEY_BX: number[] = [FOCUS[0].bx];
const KEY_BY: number[] = [FOCUS[0].by];
SCENES.forEach((s, i) => {
  if (i === 0) return;
  KEY_F.push(s.from, s.from + 26);
  KEY_AX.push(FOCUS[i - 1].ax, FOCUS[i].ax);
  KEY_AY.push(FOCUS[i - 1].ay, FOCUS[i].ay);
  KEY_BX.push(FOCUS[i - 1].bx, FOCUS[i].bx);
  KEY_BY.push(FOCUS[i - 1].by, FOCUS[i].by);
});

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const opt = { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  const ax = interpolate(frame, KEY_F, KEY_AX, opt) + Math.sin(frame / 55) * 50;
  const ay = interpolate(frame, KEY_F, KEY_AY, opt) + Math.cos(frame / 70) * 34;
  const bx = interpolate(frame, KEY_F, KEY_BX, opt) - Math.cos(frame / 62) * 44;
  const by = interpolate(frame, KEY_F, KEY_BY, opt) + Math.sin(frame / 80) * 30;
  const dots = `radial-gradient(circle, ${theme.colors.text} 1.3px, transparent 1.8px)`;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 130%)` }}>
      <div
        style={{
          position: "absolute",
          width: 1500,
          height: 1500,
          left: ax - 750,
          top: ay - 750,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${theme.colors.primary}38, ${theme.colors.primary}12 38%, transparent 66%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          left: bx - 500,
          top: by - 500,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${theme.colors.accent}1c, transparent 66%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: dots,
          backgroundSize: "64px 64px",
          backgroundPosition: `${(frame * 0.35) % 64}px ${(frame * 0.2) % 64}px`,
          opacity: 0.07,
          WebkitMaskImage: "radial-gradient(ellipse at center, #000 20%, transparent 78%)",
          maskImage: "radial-gradient(ellipse at center, #000 20%, transparent 78%)",
        }}
      />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill
      style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.22))" }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.34) 100%)",
    }}
  />
);
