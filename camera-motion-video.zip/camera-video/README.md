# ক্যামেরার ভেতরে কী ঘটে — Remotion প্রজেক্ট

    npm install
    npx remotion studio src/index.ts
    npx remotion render src/index.ts Main out/video.mp4

- কম্পোজিশন ID: `Main` (1920×1080, 30fps) — সময় সব `script/narration.srt` থেকে (`npm run cues` দিয়ে `src/data/cues.ts` নতুন করে বানান)।
- ভয়েসওভার: `public/voiceover.mp3` রাখলে Studio প্রিভিউতে বাজবে (ফ্ল্যাগ: `src/config.ts`)।
- SFX: `public/sfx/*.wav` (`npm run sfx` দিয়ে আবার তৈরি ও যাচাই)।
